package com.vauth.foxyvpn.ui.theme

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

val FoxSeed = Color(0xFF8B6CFF)
val PhantomViolet = Color(0xFF8B6CFF)
val PhantomCyan = Color(0xFF3DE8D6)
val PhantomInk = Color(0xFF090B1A)

val md_theme_light_primary = Color(0xFF5B44D9)
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_primaryContainer = Color(0xFFE4DEFF)
val md_theme_light_onPrimaryContainer = Color(0xFF1B0F5C)
val md_theme_light_inversePrimary = Color(0xFFA796FF)

val md_theme_light_secondary = Color(0xFF00796F)
val md_theme_light_onSecondary = Color(0xFFFFFFFF)
val md_theme_light_secondaryContainer = Color(0xFFB6FFF6)
val md_theme_light_onSecondaryContainer = Color(0xFF00201D)

val md_theme_light_tertiary = Color(0xFF8A5100)
val md_theme_light_onTertiary = Color(0xFFFFFFFF)
val md_theme_light_tertiaryContainer = Color(0xFFFFDDB8)
val md_theme_light_onTertiaryContainer = Color(0xFF2C1700)

val md_theme_light_error = Color(0xFFBA1A1A)
val md_theme_light_onError = Color(0xFFFFFFFF)
val md_theme_light_errorContainer = Color(0xFFFFDAD6)
val md_theme_light_onErrorContainer = Color(0xFF410002)

val md_theme_light_background = Color(0xFFF6F5FF)
val md_theme_light_onBackground = Color(0xFF14162B)
val md_theme_light_surface = Color(0xFFF6F5FF)
val md_theme_light_onSurface = Color(0xFF14162B)
val md_theme_light_surfaceVariant = Color(0xFFE6E4F5)
val md_theme_light_onSurfaceVariant = Color(0xFF4A4D6B)
val md_theme_light_surfaceTint = md_theme_light_primary

val md_theme_light_surfaceContainerLowest = Color(0xFFFFFFFF)
val md_theme_light_surfaceContainerLow = Color(0xFFF0EEFC)
val md_theme_light_surfaceContainer = Color(0xFFEAE8F8)
val md_theme_light_surfaceContainerHigh = Color(0xFFE4E2F3)
val md_theme_light_surfaceContainerHighest = Color(0xFFDEDCEE)
val md_theme_light_surfaceBright = Color(0xFFF6F5FF)
val md_theme_light_surfaceDim = Color(0xFFD8D6E8)

val md_theme_light_outline = Color(0xFF7A7D9C)
val md_theme_light_outlineVariant = Color(0xFFCBCBE3)
val md_theme_light_inverseSurface = Color(0xFF2B2D45)
val md_theme_light_inverseOnSurface = Color(0xFFF0EEFF)
val md_theme_light_scrim = Color(0xFF000000)

val md_theme_dark_primary = Color(0xFFA796FF)
val md_theme_dark_onPrimary = Color(0xFF1B0F5C)
val md_theme_dark_primaryContainer = Color(0xFF3A2A99)
val md_theme_dark_onPrimaryContainer = Color(0xFFE4DEFF)
val md_theme_dark_inversePrimary = Color(0xFF5B44D9)

val md_theme_dark_secondary = Color(0xFF5EEBDD)
val md_theme_dark_onSecondary = Color(0xFF00332E)
val md_theme_dark_secondaryContainer = Color(0xFF0F4A44)
val md_theme_dark_onSecondaryContainer = Color(0xFFB6FFF6)

val md_theme_dark_tertiary = Color(0xFFFFB86B)
val md_theme_dark_onTertiary = Color(0xFF3F2400)
val md_theme_dark_tertiaryContainer = Color(0xFF5C3600)
val md_theme_dark_onTertiaryContainer = Color(0xFFFFDDB8)

val md_theme_dark_error = Color(0xFFFF8FA3)
val md_theme_dark_onError = Color(0xFF5C0016)
val md_theme_dark_errorContainer = Color(0xFF8A1030)
val md_theme_dark_onErrorContainer = Color(0xFFFFD9DF)

val md_theme_dark_background = Color(0xFF090B1A)
val md_theme_dark_onBackground = Color(0xFFE8EAFB)
val md_theme_dark_surface = Color(0xFF090B1A)
val md_theme_dark_onSurface = Color(0xFFE8EAFB)
val md_theme_dark_surfaceVariant = Color(0xFF2A3050)
val md_theme_dark_onSurfaceVariant = Color(0xFFA9AFCF)
val md_theme_dark_surfaceTint = md_theme_dark_primary

val md_theme_dark_surfaceContainerLowest = Color(0xFF060713)
val md_theme_dark_surfaceContainerLow = Color(0xFF0E1124)
val md_theme_dark_surfaceContainer = Color(0xFF13172E)
val md_theme_dark_surfaceContainerHigh = Color(0xFF1A1F3A)
val md_theme_dark_surfaceContainerHighest = Color(0xFF232949)
val md_theme_dark_surfaceBright = Color(0xFF2A3050)
val md_theme_dark_surfaceDim = Color(0xFF090B1A)

val md_theme_dark_outline = Color(0xFF6F769C)
val md_theme_dark_outlineVariant = Color(0xFF2A3050)
val md_theme_dark_inverseSurface = Color(0xFFE8EAFB)
val md_theme_dark_inverseOnSurface = Color(0xFF181B33)
val md_theme_dark_scrim = Color(0xFF000000)

data class FoxyStatusColors(
    val connected: Color,
    val connecting: Color,
    val disconnected: Color,
)

val LightStatusColors = FoxyStatusColors(
    connected = Color(0xFF00796F),
    connecting = Color(0xFF8A5A00),
    disconnected = md_theme_light_onSurfaceVariant,
)

val DarkStatusColors = FoxyStatusColors(
    connected = Color(0xFF5EEBDD),
    connecting = Color(0xFFFFC46B),
    disconnected = md_theme_dark_onSurfaceVariant,
)

val LocalFoxyStatusColors = staticCompositionLocalOf { LightStatusColors }
