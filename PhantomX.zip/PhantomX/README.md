# Phantom X

Phantom X is a VPN client for Android with a redesigned Jetpack Compose interface.
Created by **Alireza Moghyasi**.

It is a fork of [FoxyVPN](https://github.com/Vauth/FoxyVPN) by Vauth, used under the MIT license.
The original copyright notice stays in `LICENSE`.

## Build the APK on GitHub

1. Create a **private** repository and upload this project.
2. Open **Settings > Secrets and variables > Actions** and add two secrets:
   `PHANTOM_EMAIL` and `PHANTOM_PASSWORD` (your Firefox account). Leave them out to show the normal sign-in screen.
3. Open **Actions > Phantom X build > Run workflow**.
4. When it finishes, download `phantomx-debug-apk` from the run page and install the APK.

On first launch the app shows a welcome screen (Persian) with two options: continue with the default account
(only shown when the two secrets exist) or sign in with your own Firefox account, with a short guide to create one.

The credentials are read at build time and are not stored in the source code.
Anyone who receives the APK can extract them, so keep the build for your own use.
